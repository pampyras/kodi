# -*- coding: utf-8 -*-
# Module: default
# Author: pampyras
# Created on: 28.11.2014
# License: GPL v.3 https://www.gnu.org/copyleft/gpl.html

import os
import sys
import urllib3
import urlparse
from urllib import urlencode
from urlparse import parse_qsl
import xbmcaddon
import xbmcgui
import xbmcplugin
import requests
import logging
import json
import os.path
from bs4 import BeautifulSoup
import re
import json
import sqlite3

__addon__ = xbmcaddon.Addon()
__profile__ = xbmc.translatePath( __addon__.getAddonInfo('profile') ).decode("utf-8")
__addonpath__ = __addon__.getAddonInfo('path').decode("utf-8")

#dialog = myclass("mycustom.xml", __addonpath__, 'default', '1280x720')
conn = sqlite3.connect(__profile__ + 'index.db')
tablename = "movies"


# Get the plugin url in plugin:// notation.
_url = sys.argv[0]
# Get the plugin handle as an integer number.
_handle = int(sys.argv[1])

# Free sample videos are provided by www.vidsplay.com
# Here we use a fixed set of properties simply for demonstrating purposes
# In a "real life" plugin you will need to get info and links to video files/streams
# from some web-site or online service.
VIDEOS = {'Filmai': [],
            'Serialai': [],
            'Animacija': [],
            'Paieška': [],
            'Paieškos istorija': [],
            'Beta':[],
            'Atnaujinti sąrašą':[],
            }
video_items = []
search_history = []

domain = "https://filmux.net"
            
if not os.path.exists(__profile__):
    os.makedirs(__profile__)


    
def checkTable(dbcon,tablename):
    dbcur = dbcon.cursor()
    dbcur.execute("""SELECT count(name) FROM sqlite_master WHERE type='table' AND name='{0}' """.format(tablename.replace('\'', '\'\'')))
    if dbcur.fetchone()[0] == 1:
        dbcur.close()
        return True
    else:
        dbcur.execute("""CREATE TABLE {0} (id INTEGER PRIMARY KEY, title varchar(255) NOT NULL, description TEXT NOT NULL, image varchar(255) NOT NULL, url varchar(255) NOT NULL, links TEXT NOT NULL, year varchar(255) NOT NULL, imdb varchar(255) NOT NULL, genre varchar(255) NOT NULL, type varchar(255) NOT NULL)""".format(tablename.replace('\'', '\'\'')))
    dbcur.close()
    
def fetch_movies(dbcon,tablename):
    dbcur = dbcon.cursor()
    dbcur.execute("""DELETE FROM {0}""".format(tablename.replace('\'', '\'\'')));
    dbcon.commit()
    types = ['filmai','serialai','animacija']
    for type in types:
        search_page = 1
        while True:
            url = domain+'/'+type+'/page/{0}'.format(search_page).lower()
            page = get_page(url)
            if not page.find_all('div', {"class": "short"}) or search_page == 2:
                break;
            for item in page.find_all('div', {"class": "short"}):
                img_src = item.find('img')['src']
                #img_src = img_src.replace('filmux.org','filmux.net')
                img_src = 'https://filmux.net/'+img_src
                inner_url = item.find('a')['href'].replace('filmux.org','filmux.net')
                inner_page = get_page(inner_url)
                title = inner_page.find('h1',{'class':'full__title'}).text
                year = inner_page.find('span',{'class':'full__year'}).text
                genre = inner_page.find('span',{'class':'full__genre'}).text
                imdb = inner_page.find('span',{'class':'full__imdb'}).text.strip()
                iframe_container = inner_page.find('div',{'class':"video__player"})
                iframe = iframe_container.find("iframe")
                desc = inner_page.find('div',{'class':'full__text'}).text
                type = "movie"
                iframe_page = get_page(iframe['src'].replace('filmux.org','filmux.net'),url)
                #logging.warning(page)
                url_container = re.findall('HTML5[\w\d\s.\W\D\S]+NO FLASH', iframe_page.prettify())
                if not url_container:
                    url_container = re.findall('var player[\w\W]+', iframe_page.prettify())
                links = {}
                for item in re.findall('{([^{]*?)}', url_container[0]):
                    link_title = title
                    if re.findall("comment", item):
                        link_title = re.findall("':'[\d\sA-Za-z\n\r]*",item)
                        link_title = link_title[0].lstrip("':'")
                    urls = re.findall("http[s]?:\/\/[\w\d.\/]+\/.+\/[\w\d.\/]+", item)
                    urls = urls[0].split('\',poster')
                    urls = urls[0].split('\'')
                    video = urls[0]
                    links[link_title] = video
                if (len(links) > 1):
                    type = "serial"
                records = [(title,desc,img_src,inner_url,json.dumps(links),year,imdb,genre,type)]
                #logging.warning(records)
                dbcur.executemany("""INSERT INTO {0} (title, description, image, url, links, year, imdb,genre,type) VALUES(?,?,?,?,?,?,?,?,?);""".format(tablename.replace('\'', '\'\'')),records);
            search_page += 1
    dbcon.commit()
    dbcur.close()   

def list_db_movies(dbcon,tablename):
    dbcur = dbcon.cursor()
    dbcur.execute("""SELECT * FROM {0} ORDER BY 'title' ASC;""".format(tablename.replace('\'', '\'\'')))
    rows = dbcur.fetchall()
    logging.warning(rows)
    for row in rows:
        links = json.loads(row[5])
        image = domain + row[3]
        list_item = xbmcgui.ListItem(label=row[1])
        list_item.setInfo('video', {'title':  row[1],'tagline':row[1], 'genre': row[8], 'rating': row[7], 'year': row[6], 'overlay': 5, 'plot':row[2]})
        list_item.setArt({'thumb': image, 'icon': image, 'fanart': image})
        list_item.setProperty('IsPlayable', 'true')
        is_folder = False
        if (len(links) == 1):
            xbmcplugin.addDirectoryItem(_handle, list(links.values())[0], list_item, is_folder)
    xbmcplugin.addSortMethod(_handle, xbmcplugin.SORT_METHOD_NONE)
    # Finish creating a virtual folder.
    xbmcplugin.endOfDirectory(_handle)
    dbcur.close()

def write_data(file, data):
    with open(__profile__ + file, 'wb') as outfile:
        json.dump(data, outfile)  

def get_data(file):
    if os.path.isfile(__profile__ + file):
        with open(__profile__ + file) as f:
          return json.load(f)
    else:
      return []

search_history = get_data('search.json')

video_items = get_data('search.json')
        
def get_url(**kwargs):
    """
    Create a URL for calling the plugin recursively from the given set of keyword arguments.

    :param kwargs: "argument=value" pairs
    :type kwargs: dict
    :return: plugin call URL
    :rtype: str
    """
    return '{0}?{1}'.format(_url, urlencode(kwargs))


def get_categories():
    """
    if not os.path.exists('search_history.json'):
        f = open('search_history.json', 'a+')
        f.close()
    with open('search_history.json', 'r') as f:
        history = json.load(f)   
    """
    """
    Get the list of video categories.

    Here you can insert some parsing code that retrieves
    the list of video categories (e.g. 'Movies', 'TV-shows', 'Documentaries' etc.)
    from some site or server.

    .. note:: Consider using `generator functions <https://wiki.python.org/moin/Generators>`_
        instead of returning lists.

    :return: The list of video categories
    :rtype: list
    """
    return VIDEOS.iterkeys()


def get_videos(category):
    """
    Get the list of videofiles/streams.

    Here you can insert some parsing code that retrieves
    the list of video streams in the given category from some site or server.

    .. note:: Consider using `generators functions <https://wiki.python.org/moin/Generators>`_
        instead of returning lists.

    :param category: Category name
    :type category: str
    :return: the list of videos in the category
    :rtype: list
    """
    return VIDEOS[category]

def get_page(url,referer=''):
    # download the source HTML for the page using requests
    # and parse the page using BeautifulSoup
    # proxies = {"https": "http://5.9.202.161:1080"}

    # return BeautifulSoup(requests.post(url, data = {'login_name':'','login_password':'','login':'submit'},headers={'Referer': referer}).text, 'html.parser')
    return BeautifulSoup(requests.post(url,headers={'Referer': referer}).text, 'html.parser')
    
def get_numeric_dialog( default="", heading="", dlg_type=3 ):
    """ shows a numeric dialog and returns a value
        - 0 : ShowAndGetNumber      (default format: #)
        - 1 : ShowAndGetDate            (default format: DD/MM/YYYY)
        - 2 : ShowAndGetTime            (default format: HH:MM)
        - 3 : ShowAndGetIPAddress   (default format: #.#.#.#)
    """
    dialog = xbmcgui.Dialog()
    value = dialog.numeric( dlg_type, heading, default )
    return value    

def list_categories():
    """
    Create the list of video categories in the Kodi interface.
    """
    #print data.read()
    # Get video categories
    categories = get_categories()
    # Iterate through categories
    for category in categories:
        # Create a list item with a text label and a thumbnail image.
        
        list_item = xbmcgui.ListItem(label=category)
        # Set graphics (thumbnail, fanart, banner, poster, landscape etc.) for the list item.
        # Here we use the same image for all items for simplicity's sake.
        # In a real-life plugin you need to set each image accordingly.
        #list_item.setArt({'thumb': VIDEOS[category][0]['thumb'],
        #                  'icon': VIDEOS[category][0]['thumb'],
        #                 'fanart': VIDEOS[category][0]['thumb']})
        # Set additional info for the list item.
        # Here we use a category name for both properties for for simplicity's sake.
        # setInfo allows to set various information for an item.
        # For available properties see the following link:
        # http://mirrors.xbmc.org/docs/python-docs/15.x-isengard/xbmcgui.html#ListItem-setInfo
        list_item.setInfo('video', {'title': category, 'genre': category})
        # Create a URL for a plugin recursive call.
        # Example: plugin://plugin.video.example/?action=listing&category=Animals
        url = get_url(action='listing', category=category)
        # is_folder = True means that this item opens a sub-list of lower level items.
        is_folder = True
        # Add our item to the Kodi virtual folder listing.
        xbmcplugin.addDirectoryItem(_handle, url, list_item, is_folder)
    # Add a sort method for the virtual folder items (alphabetically, ignore articles)
    
    xbmcplugin.addSortMethod(_handle, xbmcplugin.SORT_METHOD_NONE)
    # Finish creating a virtual folder.
    xbmcplugin.endOfDirectory(_handle)


def list_videos(category, search_key):
    """
    Create the list of playable videos in the Kodi interface.

    :param category: Category name
    :type category: str
    """
    if category == "Paieškos istorija":
        tmp_search = search_history
        tmp_search.reverse()
        for search in tmp_search:
          #logging.warning(search)
          title = search
          list_item = xbmcgui.ListItem(label=title)
          list_item.setInfo('video', {'title': title, 'genre': title})
          url = get_url(action='listing', category = 'Paieška', search_key = search)
          is_folder = True
          xbmcplugin.addDirectoryItem(_handle, url, list_item, is_folder)
        xbmcplugin.endOfDirectory(_handle)
    elif category == "Beta":
        list_db_movies(conn,tablename)
    elif category == 'Atnaujinti sąrašą':
        fetch_movies(conn,tablename)
    elif len(category) < 10:
        pagenb = 1
        while True:
            if category == "Paieška":
                if search_key != '':
                    url = 'https://filmux.net/index.php?do=search&subaction=search&story={0}'.format(search_key).lower()
                else:
                    dialog = xbmcgui.Dialog()
                    result = dialog.input("Įveskite paieškos žodį:", '', type=xbmcgui.INPUT_ALPHANUM)
                    if result == "":
                        list_categories()
                        return 0
                    for i, search in enumerate(search_history):
                        if result == search:
                            del search_history[i]                   
                    search_history.append(result)
                    
                    size = len(search_history)
                    if size > 15:
                        for i in reversed(range(0,size-15)):
                            del search_history[i]
                        
                    write_data('search.json', search_history)
                    url = 'https://filmux.net/index.php?do=search&subaction=search&story={0}'.format(result).lower()
            else:
                url = 'https://filmux.net/{0}/page/{1}'.format(category,pagenb).lower()
            pagenb += 1
            page = get_page(url)
            #title = soup.find("div", {"class": "short-title"})
            #title = title.find("a")
            #title_link = title["href"]
            #title = title.text

            for item in page.find_all('div', {"class": "short"}):
                # Create a list item with a text label and a thumbnail image.
                title = item.find('div',{'class':'short-title'})
                # desc = item.find('div',{'class':'short-text'})
                desc = ""
                img_src = item.find('img')['src']
                img_src = 'https://filmux.net/'+img_src
                #img_src = img_src.replace('filmux.org','filmux.net')
                #img_src = img_src.replace('filmux.org','filmux.net')
                list_item = xbmcgui.ListItem(label=title.text)
                # Set additional info for the list item.
                list_item.setInfo('video', {'title': title.text, 'plot': desc})
                # Set graphics (thumbnail, fanart, banner, poster, landscape etc.) for the list item.
                # Here we use the same image for all items for simplicity's sake.
                # In a real-life plugin you need to set each image accordingly.
                list_item.setArt({'thumb': img_src,  'fanart': img_src})
                # Set 'IsPlayable' property to 'true'.
                # This is mandatory for playable items!
                #list_item.setProperty('IsPlayable', 'true')
                # Create a URL for a plugin recursive call.
                # Example: plugin://plugin.video.example/?action=play&video=http://www.vidsplay.com/vids/crab.mp4
                url = get_url(action='listing', category = item.find('a')['href'])
                # Add the list item to a virtual Kodi folder.
                # is_folder = False means that this item won't open any sub-list.
                is_folder = True
                # Add our item to the Kodi virtual folder listing.
                xbmcplugin.addDirectoryItem(_handle, url, list_item, is_folder)
                #video_items.append([title.text, img_src, item.find('a')['href']])
            # Add a sort method for the virtual folder items (alphabetically, ignore articles)
            if not page.find_all('div', {"class": "shortstory"}) or pagenb == 5 or category == "Paieška":
                break;
        if category == "Paieška":       
            xbmcplugin.addSortMethod(_handle, xbmcplugin.SORT_METHOD_LABEL_IGNORE_THE)
            # Finish creating a virtual folder.
        xbmcplugin.endOfDirectory(_handle)
        #write_data('videos.json', video_items)
    else:
        url = category
        page = get_page(url)
        iframe_container = page.find('div',{'id':"videoblock"})
        #iframe = page.find("iframe",{'width':'560'})
        iframe = iframe_container.find("iframe")
        title = page.find("title")
        title = title.text
        desc = page.find('div',{'class':'f-text'})
        container = page.find('div',{'id':'dle-content'})
        #img_src = 'https://filmux.net/'+container.find('img',{'class':'full__bg__img'})['src']
        img_src = 'https://filmux.net/'+container.find('div',{'class':'f-poster'}).find('img')['src']
        # img_src = 'https://filmux.net/'+img_src
        #img_src = img_src.replace("background-image:url(","")
        #img_src = ""
        #title = title.find("a")
        #title_link = title["href"]
        #title = title.text
        #logging.warning(iframe)
        page = get_page(iframe['src'].replace('filmux.org','filmux.net'),url)
        #logging.warning(page)
        url_container = re.findall('HTML5[\w\d\s.\W\D\S]+NO FLASH', page.prettify())
        if not url_container:
            url_container = re.findall('var player[\w\W]+', page.prettify())
        #urls = re.findall("http[s]?:\/\/[\w\d.\/]+\/(serial|film)\/[\w\d.\/]+", page.prettify())
        #logging.warning(page.prettify())
        #for item in re.findall('{([^{]*?)}', url_container[0]):
        for item in re.findall('{([^{]*?)}', url_container[0]):

            if re.findall("comment", item):
                title = re.findall("':'[\d\sA-Za-z\n\r]*",item)
                title = title[0].lstrip("':'")
            urls = re.findall("http[s]?:\/\/[\w\d.\/]+\/.+\/[\w\d.\/]+", item)
            #logging.warning(item)
            #page = page.find(text=re.compile("'file' : '(.*)'};"));
            # Create a list item with a text label and a thumbnail image.
            list_item = xbmcgui.ListItem(label=title)
            # Set additional info for the list item.
            list_item.setInfo('video', {'title':  title,'tagline':item, 'genre': title, 'overlay': 5, 'plot':desc.text})
            # Set graphics (thumbnail, fanart, banner, poster, landscape etc.) for the list item.
            # Here we use the same image for all items for simplicity's sake.
            # In a real-life plugin you need to set each image accordingly.
            list_item.setArt({'thumb': img_src, 'icon': img_src, 'fanart': img_src})
            # Set 'IsPlayable' property to 'true'.
            # This is mandatory for playable items!
            list_item.setProperty('IsPlayable', 'true')
            # Create a URL for a plugin recursive call.
            # Example: plugin://plugin.video.example/?action=play&video=http://www.vidsplay.com/vids/crab.mp4
            urls = urls[0].split('\',poster')
            urls = urls[0].split('\'')
            #logging.warning(urls[0])
            url = get_url(action='play', video = urls[0])
            # Add the list item to a virtual Kodi folder.
            # is_folder = False means that this item won't open any sub-list.
            is_folder = False
            # Add our item to the Kodi virtual folder listing.
            xbmcplugin.addDirectoryItem(_handle, urls[0], list_item, is_folder)
        # Add a sort method for the virtual folder items (alphabetically, ignore articles)
        xbmcplugin.addSortMethod(_handle, xbmcplugin.SORT_METHOD_LABEL_IGNORE_THE)
        # Finish creating a virtual folder.
        xbmcplugin.endOfDirectory(_handle)
        
def scan_videos():
    video_items = []
    pagenb = 1
    while True:
        url = 'https://filmux.net/{0}/page/{1}'.format('filmai',pagenb).lower()
        pagenb += 1
        page = get_page(url)
        for item in page.find_all('div', {"class": "shortstory"}):
            title = item.find('div',{'class':'short-title'})
            img_src = item.find('img')['src']
            img_src = 'https://filmux.net/'+img_src
            url = item.find('a')['href']
            video_items.append([title.text, img_src, url, 'filmas'])
        if not page.find_all('div', {"class": "shortstory"}) or pagenb == 10:
            break;
        write_data('videos.json', video_items)
    
    pagenb = 1    
    while True:
        url = 'https://filmux.net/{0}/page/{1}'.format('serialai',pagenb).lower()
        pagenb += 1
        page = get_page(url)
        for item in page.find_all('div', {"class": "shortstory"}):
            title = item.find('div',{'class':'short-title'})
            img_src = item.find('img')['src']
            img_src = 'https://filmux.net/'+img_src
            url = item.find('a')['href']
            video_items.append([title.text, img_src, url, 'serialas'])
        if not page.find_all('div', {"class": "shortstory"}) or pagenb == 10:
            break;
        write_data('videos.json', video_items)        
        
def play_video(path):
    """
    Play a video by the provided path.

    :param path: Fully-qualified video URL
    :type path: str
    """
    # Create a playable item with a path to play.
    play_item = xbmcgui.ListItem(path=path)
    # Pass the item to the Kodi player.
    #dialog = xbmcgui.Dialog()
    #result = dialog.input(path, path, type=xbmcgui.INPUT_ALPHANUM)
    xbmcplugin.setResolvedUrl(_handle, True, listitem=play_item)


def router(paramstring):
    """
    Router function that calls other functions
    depending on the provided paramstring

    :param paramstring: URL encoded plugin paramstring
    :type paramstring: str
    """
    
    checkTable(conn,tablename)
    #fetch_movies(conn,tablename)
    # Parse a URL-encoded paramstring to the dictionary of
    # {<parameter>: <value>} elements
    params = dict(parse_qsl(paramstring))
    # Check the parameters passed to the plugin
    if params:
        if params['action'] == 'listing':
            # Display the list of videos in a provided category.
            search_key = ''  
            try:
                search_key = params['search_key']
            except KeyError:
                search_key = ''  
            #logging.warning(search_key)
            list_videos(params['category'], search_key)
        elif params['action'] == 'play':
            # Play a video from a provided URL.
			
            play_video(params['video'])
        else:
            # If the provided paramstring does not contain a supported action
            # we raise an exception. This helps to catch coding errors,
            # e.g. typos in action names.
            raise ValueError('Invalid paramstring: {0}!'.format(paramstring))
    else:
        # If the plugin is called from Kodi UI without any parameters,
        # display the list of video categories
        #scan_videos()
        list_categories()


if __name__ == '__main__':
    # Call the router function and pass the plugin call parameters to it.
    # We use string slicing to trim the leading '?' from the plugin call paramstring
    router(sys.argv[2][1:])
